package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.objects.SocketWrapper _socket = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static boolean _connected = false;
public b4a.example.bctoast _toast = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblname = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtname = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pane1 = null;
public anywheresoftware.b4a.objects.B4XCanvas _cvs = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panemain = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblip = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtip = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _button2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _button3 = null;
public b4a.example.starter _starter = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.b4xcollections _b4xcollections = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static class _mymessage{
public boolean IsInitialized;
public String Name;
public int Age;
public byte[] Image;
public void Initialize() {
IsInitialized = true;
Name = "";
Age = 0;
Image = new byte[0];
;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 58;BA.debugLine="Activity.LoadLayout(\"Layout\")";
mostCurrent._activity.LoadLayout("Layout",mostCurrent.activityBA);
 //BA.debugLineNum = 62;BA.debugLine="txtName.Text=\"eric\" &Rnd(0,1000)";
mostCurrent._txtname.setText(BA.ObjectToCharSequence("eric"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (1000)))));
 //BA.debugLineNum = 64;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 };
 //BA.debugLineNum = 72;BA.debugLine="Button1.Width = 180dip";
mostCurrent._button1.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (180)));
 //BA.debugLineNum = 73;BA.debugLine="Button1.Height = 150dip";
mostCurrent._button1.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150)));
 //BA.debugLineNum = 74;BA.debugLine="Button2.Width = 80dip";
mostCurrent._button2.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (80)));
 //BA.debugLineNum = 75;BA.debugLine="Button2.Height = 50dip";
mostCurrent._button2.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 76;BA.debugLine="Button3.Width = 80dip";
mostCurrent._button3.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (80)));
 //BA.debugLineNum = 77;BA.debugLine="Button3.Height = 50dip";
mostCurrent._button3.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 81;BA.debugLine="Try";
try { //BA.debugLineNum = 83;BA.debugLine="toast.Initialize(Activity)";
mostCurrent._toast._initialize /*String*/ (mostCurrent.activityBA,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(mostCurrent._activity.getObject())));
 //BA.debugLineNum = 84;BA.debugLine="toast.BB1.TextEngine.Initialize(Activity)";
mostCurrent._toast._bb1 /*b4a.example.bblabel*/ ._gettextengine /*b4a.example.bctextengine*/ ()._initialize /*String*/ (mostCurrent.activityBA,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(mostCurrent._activity.getObject())));
 } 
       catch (Exception e15) {
			processBA.setLastException(e15); //BA.debugLineNum = 88;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("1131103",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 92;BA.debugLine="timer1.Initialize(\"timer1\",1000)";
_timer1.Initialize(processBA,"timer1",(long) (1000));
 //BA.debugLineNum = 96;BA.debugLine="Try";
try { //BA.debugLineNum = 98;BA.debugLine="server.Initialize(51042,\"server\")";
_server.Initialize(processBA,(int) (51042),"server");
 //BA.debugLineNum = 101;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e22) {
			processBA.setLastException(e22); //BA.debugLineNum = 103;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("1131118",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 110;BA.debugLine="Log(\"Activity_Resume==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1196609","Activity_Resume==>",0);
 //BA.debugLineNum = 112;BA.debugLine="ObjectResize";
_objectresize();
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
b4a.example.main._mymessage _mm = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp = null;
 //BA.debugLineNum = 217;BA.debugLine="Sub astream_NewData(Buffer() As Byte)";
 //BA.debugLineNum = 218;BA.debugLine="Log(\"astream_NewData==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("115007745","astream_NewData==>",0);
 //BA.debugLineNum = 221;BA.debugLine="Dim mm As MyMessage = ser.ConvertBytesToObject(Bu";
_mm = (b4a.example.main._mymessage)(_ser.ConvertBytesToObject(_buffer));
 //BA.debugLineNum = 224;BA.debugLine="Dim bmp As B4XBitmap = LoadBitmapFromBytes(mm.Ima";
_bmp = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_bmp = _loadbitmapfrombytes(_mm.Image /*byte[]*/ );
 //BA.debugLineNum = 225;BA.debugLine="bmp = bmp.Resize(Pane1.Width, Pane1.Height, False";
_bmp = _bmp.Resize(mostCurrent._pane1.getWidth(),mostCurrent._pane1.getHeight(),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 226;BA.debugLine="cvs.ClearRect(cvs.TargetRect)";
mostCurrent._cvs.ClearRect(mostCurrent._cvs.getTargetRect());
 //BA.debugLineNum = 227;BA.debugLine="cvs.DrawBitmap(bmp, cvs.TargetRect)";
mostCurrent._cvs.DrawBitmap((android.graphics.Bitmap)(_bmp.getObject()),mostCurrent._cvs.getTargetRect());
 //BA.debugLineNum = 228;BA.debugLine="cvs.Invalidate";
mostCurrent._cvs.Invalidate();
 //BA.debugLineNum = 230;BA.debugLine="End Sub";
return "";
}
public static String  _astreams_error() throws Exception{
 //BA.debugLineNum = 232;BA.debugLine="Sub AStreams_Error";
 //BA.debugLineNum = 233;BA.debugLine="Log(\"AStreams_Error==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116777217","AStreams_Error==>",0);
 //BA.debugLineNum = 235;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("116777219",anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA).getMessage(),0);
 //BA.debugLineNum = 237;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public static String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 241;BA.debugLine="Sub AStreams_Terminated";
 //BA.debugLineNum = 242;BA.debugLine="Log(\"AStreams_Terminated==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116842753","AStreams_Terminated==>",0);
 //BA.debugLineNum = 244;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 319;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 320;BA.debugLine="Log(\"Button1_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1327681","Button1_Click==>",0);
 //BA.debugLineNum = 324;BA.debugLine="If Connected Then";
if (_connected) { 
 //BA.debugLineNum = 326;BA.debugLine="socket.Close";
_socket.Close();
 //BA.debugLineNum = 327;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 328;BA.debugLine="Connected = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 329;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 330;BA.debugLine="Button1.Text = \"連線\"";
mostCurrent._button1.setText(BA.ObjectToCharSequence("連線"));
 //BA.debugLineNum = 331;BA.debugLine="Button2.Text = \"開始傳送\"";
mostCurrent._button2.setText(BA.ObjectToCharSequence("開始傳送"));
 //BA.debugLineNum = 332;BA.debugLine="Log(\"連線斷開\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1327693","連線斷開",0);
 //BA.debugLineNum = 333;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線斷開[/color]  "));
 }else {
 //BA.debugLineNum = 335;BA.debugLine="Log(\"準備連線\")";
anywheresoftware.b4a.keywords.Common.LogImpl("1327696","準備連線",0);
 //BA.debugLineNum = 336;BA.debugLine="socket.Initialize(\"socket\")";
_socket.Initialize("socket");
 //BA.debugLineNum = 337;BA.debugLine="socket.Connect(txtIP.text, 51042 ,1000)";
_socket.Connect(processBA,mostCurrent._txtip.getText(),(int) (51042),(int) (1000));
 };
 //BA.debugLineNum = 341;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
 //BA.debugLineNum = 344;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 345;BA.debugLine="Log(\"Button2_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("115073281","Button2_Click==>",0);
 //BA.debugLineNum = 348;BA.debugLine="If Connected Then	'已連上.才能傳送";
if (_connected) { 
 //BA.debugLineNum = 350;BA.debugLine="If timer1.Enabled Then";
if (_timer1.getEnabled()) { 
 //BA.debugLineNum = 351;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 352;BA.debugLine="Button2.Text = \"開始傳送\"";
mostCurrent._button2.setText(BA.ObjectToCharSequence("開始傳送"));
 //BA.debugLineNum = 353;BA.debugLine="toast.Show($\"[b]停止傳送[/b] \"$)";
mostCurrent._toast._show /*void*/ (("[b]停止傳送[/b] "));
 }else {
 //BA.debugLineNum = 355;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 356;BA.debugLine="Button2.Text = \"停止傳送\"";
mostCurrent._button2.setText(BA.ObjectToCharSequence("停止傳送"));
 //BA.debugLineNum = 357;BA.debugLine="toast.Show($\"[b]開始傳送[/b] \"$)";
mostCurrent._toast._show /*void*/ (("[b]開始傳送[/b] "));
 };
 }else {
 //BA.debugLineNum = 362;BA.debugLine="Button2.Text = \"開始傳送\"";
mostCurrent._button2.setText(BA.ObjectToCharSequence("開始傳送"));
 //BA.debugLineNum = 363;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 364;BA.debugLine="Log(\"未連線.不可送資料\")";
anywheresoftware.b4a.keywords.Common.LogImpl("115073300","未連線.不可送資料",0);
 //BA.debugLineNum = 365;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]未連線.不可送資料[/color]  "));
 };
 //BA.debugLineNum = 369;BA.debugLine="End Sub";
return "";
}
public static String  _button3_click() throws Exception{
 //BA.debugLineNum = 374;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 375;BA.debugLine="Log(\"Button3_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116515073","Button3_Click==>",0);
 //BA.debugLineNum = 377;BA.debugLine="cvs.ClearRect(cvs.TargetRect)";
mostCurrent._cvs.ClearRect(mostCurrent._cvs.getTargetRect());
 //BA.debugLineNum = 378;BA.debugLine="cvs.Invalidate";
mostCurrent._cvs.Invalidate();
 //BA.debugLineNum = 380;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 39;BA.debugLine="Private toast As BCToast";
mostCurrent._toast = new b4a.example.bctoast();
 //BA.debugLineNum = 43;BA.debugLine="Private lblName As B4XView";
mostCurrent._lblname = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private txtName As B4XView";
mostCurrent._txtname = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private Pane1 As B4XView";
mostCurrent._pane1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private cvs As B4XCanvas	'只要宣告一個即可.不要每個地方宣告";
mostCurrent._cvs = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 48;BA.debugLine="Private PaneMain As B4XView";
mostCurrent._panemain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private lblIP As B4XView";
mostCurrent._lblip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Private txtIP As B4XView";
mostCurrent._txtip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 52;BA.debugLine="Private Button1 As B4XView";
mostCurrent._button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 53;BA.debugLine="Private Button2 As B4XView";
mostCurrent._button2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 54;BA.debugLine="Private Button3 As B4XView";
mostCurrent._button3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _loadbitmapfrombytes(byte[] _data) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bmp = null;
 //BA.debugLineNum = 247;BA.debugLine="Private Sub LoadBitmapFromBytes(Data() As Byte) As";
 //BA.debugLineNum = 248;BA.debugLine="Dim in As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 249;BA.debugLine="in.InitializeFromBytesArray(Data, 0, Data.Length)";
_in.InitializeFromBytesArray(_data,(int) (0),_data.length);
 //BA.debugLineNum = 253;BA.debugLine="Dim bmp As Bitmap";
_bmp = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 255;BA.debugLine="bmp.Initialize2(in)";
_bmp.Initialize2((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 256;BA.debugLine="Return bmp";
if (true) return (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(_bmp.getObject()));
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
return null;
}
public static String  _objectresize() throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Private Sub ObjectResize ()";
 //BA.debugLineNum = 123;BA.debugLine="PaneMain.Top=0dip";
mostCurrent._panemain.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 124;BA.debugLine="PaneMain.Left=0dip";
mostCurrent._panemain.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 125;BA.debugLine="PaneMain.Width=Activity.Width";
mostCurrent._panemain.setWidth(mostCurrent._activity.getWidth());
 //BA.debugLineNum = 127;BA.debugLine="Pane1.Top=PaneMain.Height";
mostCurrent._pane1.setTop(mostCurrent._panemain.getHeight());
 //BA.debugLineNum = 128;BA.debugLine="Pane1.Left=0dip";
mostCurrent._pane1.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 129;BA.debugLine="Pane1.Width=Activity.Width";
mostCurrent._pane1.setWidth(mostCurrent._activity.getWidth());
 //BA.debugLineNum = 130;BA.debugLine="Pane1.Height =Activity.Height - PaneMain.Height";
mostCurrent._pane1.setHeight((int) (mostCurrent._activity.getHeight()-mostCurrent._panemain.getHeight()));
 //BA.debugLineNum = 132;BA.debugLine="cvs.Initialize(Pane1)";
mostCurrent._cvs.Initialize(mostCurrent._pane1);
 //BA.debugLineNum = 135;BA.debugLine="cvs.Resize(Pane1.Width, Pane1.Height)";
mostCurrent._cvs.Resize((float) (mostCurrent._pane1.getWidth()),(float) (mostCurrent._pane1.getHeight()));
 //BA.debugLineNum = 141;BA.debugLine="lblIP.Top = 10dip";
mostCurrent._lblip.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 142;BA.debugLine="lblIP.Left = 10dip";
mostCurrent._lblip.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 143;BA.debugLine="txtIP.Top = 10dip";
mostCurrent._txtip.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 144;BA.debugLine="txtIP.Left = lblIP.Left+lblIP.Width";
mostCurrent._txtip.setLeft((int) (mostCurrent._lblip.getLeft()+mostCurrent._lblip.getWidth()));
 //BA.debugLineNum = 146;BA.debugLine="lblName.Top = txtIP.Top+lblIP.Height +20dip";
mostCurrent._lblname.setTop((int) (mostCurrent._txtip.getTop()+mostCurrent._lblip.getHeight()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (20))));
 //BA.debugLineNum = 147;BA.debugLine="lblName.Left = 10dip";
mostCurrent._lblname.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 148;BA.debugLine="txtName.Top = lblName.top";
mostCurrent._txtname.setTop(mostCurrent._lblname.getTop());
 //BA.debugLineNum = 149;BA.debugLine="txtName.Left = txtIP.Left";
mostCurrent._txtname.setLeft(mostCurrent._txtip.getLeft());
 //BA.debugLineNum = 152;BA.debugLine="Button1.Top = txtName.Top+txtName.Height+20dip";
mostCurrent._button1.setTop((int) (mostCurrent._txtname.getTop()+mostCurrent._txtname.getHeight()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (20))));
 //BA.debugLineNum = 153;BA.debugLine="Button2.Top = Button1.Top";
mostCurrent._button2.setTop(mostCurrent._button1.getTop());
 //BA.debugLineNum = 154;BA.debugLine="Button3.Top = Button1.Top";
mostCurrent._button3.setTop(mostCurrent._button1.getTop());
 //BA.debugLineNum = 155;BA.debugLine="Button1.Width = 80dip";
mostCurrent._button1.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (80)));
 //BA.debugLineNum = 156;BA.debugLine="Button1.Height = 50dip";
mostCurrent._button1.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 157;BA.debugLine="Button2.Width = 120dip";
mostCurrent._button2.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120)));
 //BA.debugLineNum = 158;BA.debugLine="Button2.Height = 50dip";
mostCurrent._button2.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 159;BA.debugLine="Button3.Width = 120dip";
mostCurrent._button3.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120)));
 //BA.debugLineNum = 160;BA.debugLine="Button3.Height = 50dip";
mostCurrent._button3.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 163;BA.debugLine="Button1.Color = xui.Color_Red";
mostCurrent._button1.setColor(_xui.Color_Red);
 //BA.debugLineNum = 164;BA.debugLine="Button1.TextColor = xui.Color_White";
mostCurrent._button1.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 165;BA.debugLine="Button2.Color = xui.Color_Yellow";
mostCurrent._button2.setColor(_xui.Color_Yellow);
 //BA.debugLineNum = 166;BA.debugLine="Button2.TextColor = xui.Color_Black";
mostCurrent._button2.setTextColor(_xui.Color_Black);
 //BA.debugLineNum = 167;BA.debugLine="Button3.Color = xui.Color_Black";
mostCurrent._button3.setColor(_xui.Color_Black);
 //BA.debugLineNum = 168;BA.debugLine="Button3.TextColor = xui.Color_White";
mostCurrent._button3.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public static String  _pane1_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 285;BA.debugLine="Private Sub Pane1_Touch (Action As Int, X As Float";
 //BA.debugLineNum = 286;BA.debugLine="Log(\"Pane1_Touch==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("114876673","Pane1_Touch==>",0);
 //BA.debugLineNum = 289;BA.debugLine="Try";
try { //BA.debugLineNum = 291;BA.debugLine="cvs.DrawCircle(x, y, 5dip , xui.Color_Black  , T";
mostCurrent._cvs.DrawCircle(_x,_y,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))),_xui.Color_Black,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0))));
 //BA.debugLineNum = 295;BA.debugLine="cvs.Invalidate";
mostCurrent._cvs.Invalidate();
 } 
       catch (Exception e6) {
			processBA.setLastException(e6); //BA.debugLineNum = 298;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("114876685",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 301;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
starter._process_globals();
httputils2service._process_globals();
b4xcollections._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 21;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 25;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private socket As Socket";
_socket = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 28;BA.debugLine="Private ser As B4XSerializator";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 30;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 31;BA.debugLine="Private Connected As Boolean = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 33;BA.debugLine="Type MyMessage (Name As String, Age As Int, Image";
;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public static String  _senddata() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
b4a.example.main._mymessage _m1 = null;
 //BA.debugLineNum = 260;BA.debugLine="Sub SendData()";
 //BA.debugLineNum = 262;BA.debugLine="Dim bmp As B4XBitmap";
_bmp = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 264;BA.debugLine="bmp = cvs.CreateBitmap";
_bmp = mostCurrent._cvs.CreateBitmap();
 //BA.debugLineNum = 267;BA.debugLine="Dim out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 268;BA.debugLine="out.InitializeToBytesArray(0)";
_out.InitializeToBytesArray((int) (0));
 //BA.debugLineNum = 269;BA.debugLine="bmp.WriteToStream(out, 100, \"PNG\")";
_bmp.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"PNG"));
 //BA.debugLineNum = 270;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 272;BA.debugLine="Dim m1 As MyMessage";
_m1 = new b4a.example.main._mymessage();
 //BA.debugLineNum = 274;BA.debugLine="m1.Image =	out.ToBytesArray";
_m1.Image /*byte[]*/  = _out.ToBytesArray();
 //BA.debugLineNum = 276;BA.debugLine="Try";
try { //BA.debugLineNum = 278;BA.debugLine="astream.Write(ser.ConvertObjectToBytes(m1))";
_astream.Write(_ser.ConvertObjectToBytes((Object)(_m1)));
 } 
       catch (Exception e12) {
			processBA.setLastException(e12); //BA.debugLineNum = 280;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("116580628",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 283;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 171;BA.debugLine="Sub server_NewConnection (Successful As Boolean, N";
 //BA.debugLineNum = 172;BA.debugLine="Log(\"server_NewConnection==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("114942209","server_NewConnection==>",0);
 //BA.debugLineNum = 174;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 176;BA.debugLine="Try";
try { //BA.debugLineNum = 177;BA.debugLine="socket = NewSocket";
_socket = _newsocket;
 //BA.debugLineNum = 178;BA.debugLine="astream.InitializePrefix(socket.InputStream,Tru";
_astream.InitializePrefix(processBA,_socket.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_socket.getOutputStream(),"astream");
 } 
       catch (Exception e7) {
			processBA.setLastException(e7); //BA.debugLineNum = 180;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("114942217",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(mostCurrent.activityBA)),0);
 };
 //BA.debugLineNum = 182;BA.debugLine="Button1.Text = \"斷開\"";
mostCurrent._button1.setText(BA.ObjectToCharSequence("斷開"));
 //BA.debugLineNum = 183;BA.debugLine="Connected = True	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 184;BA.debugLine="Log(\"新的連線OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("114942221","新的連線OK",0);
 //BA.debugLineNum = 185;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]新的連線OK[/color]  "));
 }else {
 //BA.debugLineNum = 188;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 189;BA.debugLine="Log(\"新的連線Fail\")";
anywheresoftware.b4a.keywords.Common.LogImpl("114942226","新的連線Fail",0);
 //BA.debugLineNum = 190;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]新的連線失敗[/color]  "));
 };
 //BA.debugLineNum = 193;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return "";
}
public static String  _socket_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 198;BA.debugLine="Sub socket_Connected (Successful As Boolean)";
 //BA.debugLineNum = 199;BA.debugLine="Log(\"socket_Connected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116646145","socket_Connected==>",0);
 //BA.debugLineNum = 202;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 203;BA.debugLine="astream.InitializePrefix(socket.InputStream,True";
_astream.InitializePrefix(processBA,_socket.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_socket.getOutputStream(),"astream");
 //BA.debugLineNum = 204;BA.debugLine="Button1.Text = \"斷開\"";
mostCurrent._button1.setText(BA.ObjectToCharSequence("斷開"));
 //BA.debugLineNum = 205;BA.debugLine="Connected = True	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 206;BA.debugLine="Log(\"連線OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116646152","連線OK",0);
 //BA.debugLineNum = 207;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線OK[/color]  "));
 }else {
 //BA.debugLineNum = 210;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 211;BA.debugLine="Log(\"連線Fail\")";
anywheresoftware.b4a.keywords.Common.LogImpl("116646157","連線Fail",0);
 //BA.debugLineNum = 212;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
mostCurrent._toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線失敗[/color]  "));
 };
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 303;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 304;BA.debugLine="Log(\"Timer1_Tick==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("115990785","Timer1_Tick==>",0);
 //BA.debugLineNum = 306;BA.debugLine="If Connected Then	'已連上.才能傳送";
if (_connected) { 
 //BA.debugLineNum = 307;BA.debugLine="Button1.Text = \"斷開\"";
mostCurrent._button1.setText(BA.ObjectToCharSequence("斷開"));
 //BA.debugLineNum = 308;BA.debugLine="SendData";
_senddata();
 }else {
 //BA.debugLineNum = 310;BA.debugLine="Button1.Text = \"連線\"";
mostCurrent._button1.setText(BA.ObjectToCharSequence("連線"));
 //BA.debugLineNum = 311;BA.debugLine="Button2.Text = \"開始傳送\"";
mostCurrent._button2.setText(BA.ObjectToCharSequence("開始傳送"));
 //BA.debugLineNum = 312;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 313;BA.debugLine="Log(\"未連線.不可送資料\")";
anywheresoftware.b4a.keywords.Common.LogImpl("115990794","未連線.不可送資料",0);
 };
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
}
