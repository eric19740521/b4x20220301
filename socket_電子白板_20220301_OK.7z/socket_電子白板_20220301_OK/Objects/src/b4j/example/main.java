package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.objects.SocketWrapper _socket = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
public static b4j.example.bctoast _toast = null;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static boolean _connected = false;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblname = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtname = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _pane1 = null;
public static anywheresoftware.b4a.objects.B4XCanvas _cvs = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _lblip = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtip = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button3 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _panemain = null;
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.b4xcollections _b4xcollections = null;
public static class _mymessage{
public boolean IsInitialized;
public String Name;
public int Age;
public byte[] Image;
public void Initialize() {
IsInitialized = true;
Name = "";
Age = 0;
Image = new byte[0];
;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 46;BA.debugLine="Log(\"AppStart==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("465537","AppStart==>",0);
 //BA.debugLineNum = 50;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 51;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 55;BA.debugLine="txtName.Text=\"eric\" &Rnd(0,1000)";
_txtname.setText("eric"+BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (1000))));
 //BA.debugLineNum = 60;BA.debugLine="cvs.Initialize(Pane1)";
_cvs.Initialize(ba,_pane1);
 //BA.debugLineNum = 61;BA.debugLine="cvs.Resize(Pane1.Width, Pane1.Height)";
_cvs.Resize(_pane1.getWidth(),_pane1.getHeight());
 //BA.debugLineNum = 67;BA.debugLine="cvs.Resize(Pane1.Width, Pane1.Height)";
_cvs.Resize(_pane1.getWidth(),_pane1.getHeight());
 //BA.debugLineNum = 76;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 79;BA.debugLine="PaneMain.Top=0dip";
_panemain.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 80;BA.debugLine="PaneMain.Left=0dip";
_panemain.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 81;BA.debugLine="PaneMain.Width=MainForm.Width";
_panemain.setWidth(_mainform.getWidth());
 //BA.debugLineNum = 83;BA.debugLine="Pane1.Top=PaneMain.Height";
_pane1.setTop(_panemain.getHeight());
 //BA.debugLineNum = 84;BA.debugLine="Pane1.Left=0dip";
_pane1.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 85;BA.debugLine="Pane1.Width=MainForm.Width";
_pane1.setWidth(_mainform.getWidth());
 //BA.debugLineNum = 86;BA.debugLine="Pane1.Height =MainForm.Height - PaneMain.Height";
_pane1.setHeight(_mainform.getHeight()-_panemain.getHeight());
 //BA.debugLineNum = 91;BA.debugLine="Try";
try { //BA.debugLineNum = 93;BA.debugLine="toast.Initialize(MainForm.RootPane)";
_toast._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mainform.getRootPane().getObject())));
 //BA.debugLineNum = 94;BA.debugLine="toast.BB1.TextEngine.Initialize(MainForm.RootPan";
_toast._bb1 /*b4j.example.bblabel*/ ._gettextengine /*b4j.example.bctextengine*/ ()._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mainform.getRootPane().getObject())));
 //BA.debugLineNum = 95;BA.debugLine="toast.BB1.TextEngine.CustomFonts.Put(\"italic\", x";
_toast._bb1 /*b4j.example.bblabel*/ ._gettextengine /*b4j.example.bctextengine*/ ()._customfonts /*anywheresoftware.b4a.objects.collections.Map*/ .Put((Object)("italic"),(Object)(_xui.CreateFont((javafx.scene.text.Font)(_fx.CreateFont("arial",10,anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.True).getObject()),(float) (10)).getObject()));
 } 
       catch (Exception e21) {
			ba.setLastException(e21); //BA.debugLineNum = 98;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("465589",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 102;BA.debugLine="timer1.Initialize(\"timer1\",1000)";
_timer1.Initialize(ba,"timer1",(long) (1000));
 //BA.debugLineNum = 105;BA.debugLine="Try";
try { //BA.debugLineNum = 107;BA.debugLine="server.Initialize(51042,\"server\")";
_server.Initialize(ba,(int) (51042),"server");
 //BA.debugLineNum = 109;BA.debugLine="MainForm.Title =\"電子白板 (MyIP:\" & server.GetMyIP &";
_mainform.setTitle("電子白板 (MyIP:"+_server.GetMyIP()+")");
 //BA.debugLineNum = 112;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e29) {
			ba.setLastException(e29); //BA.debugLineNum = 114;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("465605",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
b4j.example.main._mymessage _mm = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp = null;
 //BA.debugLineNum = 212;BA.debugLine="Sub astream_NewData(Buffer() As Byte)";
 //BA.debugLineNum = 213;BA.debugLine="Log(\"astream_NewData==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("415597569","astream_NewData==>",0);
 //BA.debugLineNum = 216;BA.debugLine="Dim mm As MyMessage = ser.ConvertBytesToObject(Bu";
_mm = (b4j.example.main._mymessage)(_ser.ConvertBytesToObject(_buffer));
 //BA.debugLineNum = 219;BA.debugLine="Dim bmp As B4XBitmap = LoadBitmapFromBytes(mm.Ima";
_bmp = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_bmp = _loadbitmapfrombytes(_mm.Image /*byte[]*/ );
 //BA.debugLineNum = 220;BA.debugLine="bmp = bmp.Resize(Pane1.Width, Pane1.Height, False";
_bmp = _bmp.Resize((int) (_pane1.getWidth()),(int) (_pane1.getHeight()),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 221;BA.debugLine="cvs.ClearRect(cvs.TargetRect)";
_cvs.ClearRect(_cvs.getTargetRect());
 //BA.debugLineNum = 222;BA.debugLine="cvs.DrawBitmap(bmp, cvs.TargetRect)";
_cvs.DrawBitmap((javafx.scene.image.Image)(_bmp.getObject()),_cvs.getTargetRect());
 //BA.debugLineNum = 223;BA.debugLine="cvs.Invalidate";
_cvs.Invalidate();
 //BA.debugLineNum = 225;BA.debugLine="End Sub";
return "";
}
public static String  _astreams_error() throws Exception{
 //BA.debugLineNum = 227;BA.debugLine="Sub AStreams_Error";
 //BA.debugLineNum = 228;BA.debugLine="Log(\"AStreams_Error==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("417956865","AStreams_Error==>",0);
 //BA.debugLineNum = 230;BA.debugLine="Log(LastException.Message)";
anywheresoftware.b4a.keywords.Common.LogImpl("417956867",anywheresoftware.b4a.keywords.Common.LastException(ba).getMessage(),0);
 //BA.debugLineNum = 232;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 234;BA.debugLine="End Sub";
return "";
}
public static String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 236;BA.debugLine="Sub AStreams_Terminated";
 //BA.debugLineNum = 237;BA.debugLine="Log(\"AStreams_Terminated==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("418022401","AStreams_Terminated==>",0);
 //BA.debugLineNum = 239;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 338;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 339;BA.debugLine="Log(\"Button1_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("4131073","Button1_Click==>",0);
 //BA.debugLineNum = 343;BA.debugLine="If Connected Then";
if (_connected) { 
 //BA.debugLineNum = 345;BA.debugLine="socket.Close";
_socket.Close();
 //BA.debugLineNum = 346;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 347;BA.debugLine="Connected = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 348;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 349;BA.debugLine="Button1.Text = \"連線\"";
_button1.setText("連線");
 //BA.debugLineNum = 350;BA.debugLine="Button2.Text = \"開始傳送\"";
_button2.setText("開始傳送");
 //BA.debugLineNum = 351;BA.debugLine="Log(\"連線斷開\")";
anywheresoftware.b4a.keywords.Common.LogImpl("4131085","連線斷開",0);
 //BA.debugLineNum = 352;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線斷開[/color]  "));
 }else {
 //BA.debugLineNum = 354;BA.debugLine="Log(\"準備連線\")";
anywheresoftware.b4a.keywords.Common.LogImpl("4131088","準備連線",0);
 //BA.debugLineNum = 355;BA.debugLine="socket.Initialize(\"socket\")";
_socket.Initialize("socket");
 //BA.debugLineNum = 356;BA.debugLine="socket.Connect(txtIP.text, 51042 ,1000)";
_socket.Connect(ba,_txtip.getText(),(int) (51042),(int) (1000));
 };
 //BA.debugLineNum = 360;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
 //BA.debugLineNum = 363;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 364;BA.debugLine="Log(\"Button2_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416908289","Button2_Click==>",0);
 //BA.debugLineNum = 367;BA.debugLine="If Connected Then	'已連上.才能傳送";
if (_connected) { 
 //BA.debugLineNum = 369;BA.debugLine="If timer1.Enabled Then";
if (_timer1.getEnabled()) { 
 //BA.debugLineNum = 370;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 371;BA.debugLine="Button2.Text = \"開始傳送\"";
_button2.setText("開始傳送");
 //BA.debugLineNum = 372;BA.debugLine="toast.Show($\"[b]停止傳送[/b] \"$)";
_toast._show /*void*/ (("[b]停止傳送[/b] "));
 }else {
 //BA.debugLineNum = 374;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 375;BA.debugLine="Button2.Text = \"停止傳送\"";
_button2.setText("停止傳送");
 //BA.debugLineNum = 376;BA.debugLine="toast.Show($\"[b]開始傳送[/b] \"$)";
_toast._show /*void*/ (("[b]開始傳送[/b] "));
 };
 }else {
 //BA.debugLineNum = 381;BA.debugLine="Button2.Text = \"開始傳送\"";
_button2.setText("開始傳送");
 //BA.debugLineNum = 382;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 383;BA.debugLine="Log(\"未連線.不可送資料\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416908308","未連線.不可送資料",0);
 //BA.debugLineNum = 384;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]未連線.不可送資料[/color]  "));
 };
 //BA.debugLineNum = 389;BA.debugLine="End Sub";
return "";
}
public static String  _button3_click() throws Exception{
 //BA.debugLineNum = 394;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 395;BA.debugLine="Log(\"Button3_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416973825","Button3_Click==>",0);
 //BA.debugLineNum = 397;BA.debugLine="cvs.ClearRect(cvs.TargetRect)";
_cvs.ClearRect(_cvs.getTargetRect());
 //BA.debugLineNum = 398;BA.debugLine="cvs.Invalidate";
_cvs.Invalidate();
 //BA.debugLineNum = 400;BA.debugLine="End Sub";
return "";
}
public static String  _canvas1_mousedragged(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 261;BA.debugLine="Sub Canvas1_MouseDragged (EventData As MouseEvent)";
 //BA.debugLineNum = 262;BA.debugLine="Log(\"Canvas1_MouseDragged==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("415728641","Canvas1_MouseDragged==>",0);
 //BA.debugLineNum = 265;BA.debugLine="Try";
try { //BA.debugLineNum = 267;BA.debugLine="cvs.DrawCircle(EventData.x, EventData.y, 5dip ,";
_cvs.DrawCircle((float) (_eventdata.getX()),(float) (_eventdata.getY()),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5))),_xui.Color_Black,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0))));
 //BA.debugLineNum = 271;BA.debugLine="cvs.Invalidate";
_cvs.Invalidate();
 } 
       catch (Exception e6) {
			ba.setLastException(e6); //BA.debugLineNum = 274;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("415728653",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _loadbitmapfrombytes(byte[] _data) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bmp = null;
 //BA.debugLineNum = 243;BA.debugLine="Private Sub LoadBitmapFromBytes(Data() As Byte) As";
 //BA.debugLineNum = 244;BA.debugLine="Dim in As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 245;BA.debugLine="in.InitializeFromBytesArray(Data, 0, Data.Length)";
_in.InitializeFromBytesArray(_data,(int) (0),_data.length);
 //BA.debugLineNum = 247;BA.debugLine="Dim bmp As Image";
_bmp = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 251;BA.debugLine="bmp.Initialize2(in)";
_bmp.Initialize2((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 252;BA.debugLine="Return bmp";
if (true) return (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (javafx.scene.image.Image)(_bmp.getObject()));
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return null;
}
public static String  _mainform_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub MainForm_Resize (Width As Double, Heig";
 //BA.debugLineNum = 124;BA.debugLine="PaneMain.Top=0dip";
_panemain.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 125;BA.debugLine="PaneMain.Left=0dip";
_panemain.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 126;BA.debugLine="PaneMain.Width=MainForm.Width";
_panemain.setWidth(_mainform.getWidth());
 //BA.debugLineNum = 128;BA.debugLine="Pane1.Top=PaneMain.Height";
_pane1.setTop(_panemain.getHeight());
 //BA.debugLineNum = 129;BA.debugLine="Pane1.Left=0dip";
_pane1.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 130;BA.debugLine="Pane1.Width=MainForm.Width";
_pane1.setWidth(_mainform.getWidth());
 //BA.debugLineNum = 131;BA.debugLine="Pane1.Height =MainForm.Height - PaneMain.Height";
_pane1.setHeight(_mainform.getHeight()-_panemain.getHeight());
 //BA.debugLineNum = 135;BA.debugLine="cvs.Resize(Pane1.Width, Pane1.Height)";
_cvs.Resize(_pane1.getWidth(),_pane1.getHeight());
 //BA.debugLineNum = 141;BA.debugLine="lblIP.Top = 10dip";
_lblip.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 142;BA.debugLine="lblIP.Left = 10dip";
_lblip.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 143;BA.debugLine="txtIP.Top = 10dip";
_txtip.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 144;BA.debugLine="txtIP.Left = lblIP.Left+lblIP.Width";
_txtip.setLeft(_lblip.getLeft()+_lblip.getWidth());
 //BA.debugLineNum = 146;BA.debugLine="lblName.Top = txtIP.Top+lblIP.Height +20dip";
_lblname.setTop(_txtip.getTop()+_lblip.getHeight()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (20)));
 //BA.debugLineNum = 147;BA.debugLine="lblName.Left = 10dip";
_lblname.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10)));
 //BA.debugLineNum = 148;BA.debugLine="txtName.Top = lblName.top";
_txtname.setTop(_lblname.getTop());
 //BA.debugLineNum = 149;BA.debugLine="txtName.Left = txtIP.Left";
_txtname.setLeft(_txtip.getLeft());
 //BA.debugLineNum = 152;BA.debugLine="Button1.Width = 80dip";
_button1.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (80)));
 //BA.debugLineNum = 153;BA.debugLine="Button1.Height = 50dip";
_button1.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 154;BA.debugLine="Button2.Width = 120dip";
_button2.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120)));
 //BA.debugLineNum = 155;BA.debugLine="Button2.Height = 50dip";
_button2.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 156;BA.debugLine="Button3.Width = 120dip";
_button3.setWidth(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120)));
 //BA.debugLineNum = 157;BA.debugLine="Button3.Height = 50dip";
_button3.setHeight(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)));
 //BA.debugLineNum = 160;BA.debugLine="Button1.Color = xui.Color_Red";
_button1.setColor(_xui.Color_Red);
 //BA.debugLineNum = 161;BA.debugLine="Button1.TextColor = xui.Color_White";
_button1.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 162;BA.debugLine="Button2.Color = xui.Color_Yellow";
_button2.setColor(_xui.Color_Yellow);
 //BA.debugLineNum = 163;BA.debugLine="Button2.TextColor = xui.Color_Black";
_button2.setTextColor(_xui.Color_Black);
 //BA.debugLineNum = 164;BA.debugLine="Button3.Color = xui.Color_Black";
_button3.setColor(_xui.Color_Black);
 //BA.debugLineNum = 165;BA.debugLine="Button3.TextColor = xui.Color_White";
_button3.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public static String  _pane1_mousedragged(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 279;BA.debugLine="Private Sub Pane1_MouseDragged (EventData As Mouse";
 //BA.debugLineNum = 280;BA.debugLine="Log(\"Pane1_MouseDragged==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("415859713","Pane1_MouseDragged==>",0);
 //BA.debugLineNum = 295;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
httputils2service._process_globals();
b4xcollections._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private socket As Socket";
_socket = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 15;BA.debugLine="Private ser As B4XSerializator";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 17;BA.debugLine="Private toast As BCToast";
_toast = new b4j.example.bctoast();
 //BA.debugLineNum = 18;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 20;BA.debugLine="Private Connected As Boolean = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 24;BA.debugLine="Type MyMessage (Name As String, Age As Int, Image";
;
 //BA.debugLineNum = 27;BA.debugLine="Private lblName As B4XView";
_lblname = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private txtName As B4XView";
_txtname = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private Pane1 As B4XView";
_pane1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private cvs As B4XCanvas	'只要宣告一個即可.不要每個地方宣告";
_cvs = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 38;BA.debugLine="Private lblIP As B4XView";
_lblip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private txtIP As B4XView";
_txtip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private Button2 As B4XView";
_button2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private Button3 As B4XView";
_button3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private PaneMain As B4XView";
_panemain = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public static String  _senddata() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _bmp = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
b4j.example.main._mymessage _m1 = null;
 //BA.debugLineNum = 297;BA.debugLine="Sub SendData()";
 //BA.debugLineNum = 299;BA.debugLine="Dim bmp As B4XBitmap		'B4XBitmap Wrapper for Bitm";
_bmp = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 301;BA.debugLine="bmp = cvs.CreateBitmap";
_bmp = _cvs.CreateBitmap();
 //BA.debugLineNum = 304;BA.debugLine="Dim out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 305;BA.debugLine="out.InitializeToBytesArray(0)";
_out.InitializeToBytesArray((int) (0));
 //BA.debugLineNum = 306;BA.debugLine="bmp.WriteToStream(out, 100, \"PNG\")";
_bmp.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),"PNG");
 //BA.debugLineNum = 307;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 309;BA.debugLine="Dim m1 As MyMessage";
_m1 = new b4j.example.main._mymessage();
 //BA.debugLineNum = 311;BA.debugLine="m1.Image =	out.ToBytesArray";
_m1.Image /*byte[]*/  = _out.ToBytesArray();
 //BA.debugLineNum = 313;BA.debugLine="Try";
try { //BA.debugLineNum = 315;BA.debugLine="astream.Write(ser.ConvertObjectToBytes(m1))";
_astream.Write(_ser.ConvertObjectToBytes((Object)(_m1)));
 } 
       catch (Exception e12) {
			ba.setLastException(e12); //BA.debugLineNum = 317;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("417498132",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 320;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 168;BA.debugLine="Sub server_NewConnection (Successful As Boolean, N";
 //BA.debugLineNum = 169;BA.debugLine="Log(\"server_NewConnection==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("41507329","server_NewConnection==>",0);
 //BA.debugLineNum = 171;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 173;BA.debugLine="Try";
try { //BA.debugLineNum = 174;BA.debugLine="socket = NewSocket";
_socket = _newsocket;
 //BA.debugLineNum = 175;BA.debugLine="astream.InitializePrefix(socket.InputStream,Tru";
_astream.InitializePrefix(ba,_socket.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_socket.getOutputStream(),"astream");
 } 
       catch (Exception e7) {
			ba.setLastException(e7); //BA.debugLineNum = 177;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("41507337",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 };
 //BA.debugLineNum = 179;BA.debugLine="Button1.Text = \"斷開\"";
_button1.setText("斷開");
 //BA.debugLineNum = 180;BA.debugLine="Connected = True	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 181;BA.debugLine="Log(\"新的連線OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("41507341","新的連線OK",0);
 //BA.debugLineNum = 182;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]新的連線OK[/color]  "));
 }else {
 //BA.debugLineNum = 185;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 186;BA.debugLine="Log(\"新的連線Fail\")";
anywheresoftware.b4a.keywords.Common.LogImpl("41507346","新的連線Fail",0);
 //BA.debugLineNum = 187;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]新的連線失敗[/color]  "));
 };
 //BA.debugLineNum = 190;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return "";
}
public static String  _socket_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 194;BA.debugLine="Sub socket_Connected (Successful As Boolean)";
 //BA.debugLineNum = 195;BA.debugLine="Log(\"socket_Connected==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416842753","socket_Connected==>",0);
 //BA.debugLineNum = 197;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 198;BA.debugLine="astream.InitializePrefix(socket.InputStream,True";
_astream.InitializePrefix(ba,_socket.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_socket.getOutputStream(),"astream");
 //BA.debugLineNum = 199;BA.debugLine="Button1.Text = \"斷開\"";
_button1.setText("斷開");
 //BA.debugLineNum = 200;BA.debugLine="Connected = True	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 201;BA.debugLine="Log(\"連線OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416842759","連線OK",0);
 //BA.debugLineNum = 202;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線OK[/color]  "));
 }else {
 //BA.debugLineNum = 205;BA.debugLine="Connected = False	'連線狀態";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 206;BA.debugLine="Log(\"連線Fail\")";
anywheresoftware.b4a.keywords.Common.LogImpl("416842764","連線Fail",0);
 //BA.debugLineNum = 207;BA.debugLine="toast.Show($\"[b]連線狀態[/b][TextSize=25][color=#ff0";
_toast._show /*void*/ (("[b]連線狀態[/b][TextSize=25][color=#ff00ff]連線失敗[/color]  "));
 };
 //BA.debugLineNum = 210;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 322;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 323;BA.debugLine="Log(\"Timer1_Tick==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("417104897","Timer1_Tick==>",0);
 //BA.debugLineNum = 325;BA.debugLine="If Connected Then	'已連上.才能傳送";
if (_connected) { 
 //BA.debugLineNum = 326;BA.debugLine="Button1.Text = \"斷開\"";
_button1.setText("斷開");
 //BA.debugLineNum = 327;BA.debugLine="SendData";
_senddata();
 }else {
 //BA.debugLineNum = 329;BA.debugLine="Button1.Text = \"連線\"";
_button1.setText("連線");
 //BA.debugLineNum = 330;BA.debugLine="Button2.Text = \"開始傳送\"";
_button2.setText("開始傳送");
 //BA.debugLineNum = 331;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 332;BA.debugLine="Log(\"未連線.不可送資料\")";
anywheresoftware.b4a.keywords.Common.LogImpl("417104906","未連線.不可送資料",0);
 };
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return "";
}
}
